CREATE DATABASE  demo;
use demo;
--  EID NAME ADDR CITY DOB PHONE EMAIL id should be like ‘E0001'
CREATE TABLE EMP(eid CHAR(10) ,name varchar(20),addr varchar(20),dob char(10),phone int(10),email_id varchar(20));
ALTER TABLE EMP  add address varchar(20);
ALTER TABLE EMP  add DOJ DATE;
DELETE from emp where eid='E0005';
ALTER TABLE EMP modify column eid char(10) primary key;
INSERT INTO  EMP
 values ('E0001','neha','banglore','1999-02-02',82067489,'maha@gmail.com'),
  ('E0002','haritha','banglore','1979-07-02',820678989,'harita@gmail.com');
  INSERT INTO  EMP
  values('E0003','hamritha','banglddore','1979-07-02',820678989,'hardita@gmail.com'),
  ('E0004','maritha','lddore','1979-07-02',92068989,'hta@gmail.com');
  
SELECT * FROM emp;
update emp set email_id='neha@gmail.com' where name='neha';
set @@session.sql_safe_updates=1;
create table EMP_SAL(EID char(10),dept varchar(10),desi char(10),doj date,salary int);
ALTER TABLE EMP_SAL modify column desi varchar(40) ;
ALTER TABLE EMP_SAL modify column eid char(10) ;
insert into emp_sal values( 'E0004','prod','associate','2016-11-07',10000);
select * from emp_sal;
delete from emp_sal where salary=40000;
delete from emp_sal where eid='e0004' and desi='associate';
select * from emp;
alter table emp_sal 
add constraint f foreign key (eid) references emp(eid);

update emp_sal set eid='e0002' where dept='support';
alter table emp drop doj