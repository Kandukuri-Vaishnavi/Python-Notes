

create database DEMO1;
use demo1;

create table EMP 
( EID char(5),
Name varchar(30),
ADDR varchar(50),
CITY varchar(20),
DOB date,
PHONE char(15),
EMAIL varchar(30)); 


Select * from EMP;

Insert into EMP 
values( 'E0001', 'Ajay Mishra', '36 Banjara Hills', 'Hyderabad', '1969-11-26', '9966258526', 'Amishra2611@yahoo.com');

Insert into EMP 
values( 'E0002', 'Ronak patel', '556-B block Gandhi street ', 'Kolkata', '1989-08-17', '9966288858', 'rushto_patel@yahoo.com'),
( 'E0003', 'Priyanka karnan', '223-c, police qtrs Tambaram', 'Chennai', '1995-08-13', '9966296963', 'priyak_Chennai@gmail.com'),
( 'E0004', 'Suhas Sharma', 'hno 34/a, aerocity', 'Delhi', '1996-02-08', '9966200052', 'mail2suhas@gmail.com'),
( 'E0005', 'Kabir Krishna', '84 Shantinagar Masab Tank', 'Hyderabad', '1984-04-09', '9966255448', 'reach_kk@gmail.com'),
( 'E0006', 'Rushang Varma', '2/4 G.K. Mansions, waltair ', 'Vizag', '1986-06-1', '9988850062', 'rushto_rushi@gmail.com'),
( 'E0007', 'Shalini Komaragiri', 'apt 4509 10th st, Kali Ghat rd, ', 'Kolkata', '1995-09-11', '9696932321', 'mailme_shalini@yahoo.com'),
( 'E0008', 'Amit Varma', '365 SadaSiva nagar', 'Bangalore', '1975-01-22', '4038285544', 'Amit_capri@gmail.com'),
( 'E0009', 'Rupesh Choudary', 'c-244 Madhura nagar', 'Hyderabad', '1980-08-12', '9394948000', 'rushto_rc1208@yahoo.com'),
( 'E0010', 'Aswini Rajagopalan', '843-c, Kamala Nagar', 'Delhi', '1995-10-31', '9394948554', 'AsRaja007@gmail.com');


create table EMP_SAL
( EID char(5),
DEPT varchar(10),
Desi varchar(20),
DOJ date,
Salary float);

insert into EMP_Sal 
values('E0001', 'IT', 'Director', '2020-05-01', 595000),
('E0003', 'Admin', 'Manager', '2018-06-15', 105000),
('E0004', 'MIS', 'Asst. Manager', '2021-01-05', 75000),
('E0005', 'IT', 'Asst Manager', '2022-01-01', 95000),
('E0006', 'OPS', 'Consultant', '2019-08-26', 255000),
('E0007', 'OPS', 'Manager', '2021-04-26', 150000),
('E0008', 'IT', 'Associate', '2022-09-01', 75000);

select * from EMP_Sal;

-- from EMP table list all the employees with last name as sharma

select * from emp
where name like '%Sharma';



-- increase the salary of all the managers by 10%

update emp_sal set Salary = 1.10*salary
where desi = 'Manager';

select * from emp_sal;


-----------Assignment 3 ------------------------------------

use DEMO1;
alter table emp alter column eid char(5) not null;
Alter table emp
add constraint pkid primary key (Eid);

alter table emp 
alter column eid char(5) not null;

alter table emp
alter column name varchar(30) not null;

alter table emp
add constraint ch_addr check (not addr like '%Uttam Nagar%');

alter table emp 
add constraint ch_city check ( city in ('DELhi', 'Gurgaon', 'Faridabad', 'Noida'));

delete from emp;
 

Insert into EMP 
values( 'E0001', 'Ajay Mishra', '36 Banjara Hills', 'Delhi', '1969-11-26', '9966258526', 'Amishra2611@yahoo.com');

Insert into EMP 
values( 'E0002', 'Ronak patel', '556-B block Gandhi street ', 'Gurgaon', '1989-08-17', '9966288858', 'rushto_patel@yahoo.com'),
( 'E0003', 'Priyanka karnan', '223-c, police qtrs Tambaram', 'Delhi', '1995-08-13', '9966296963', 'priyak_Chennai@gmail.com'),
( 'E0004', 'Suhas Sharma', 'hno 34/a, aerocity', 'Delhi', '1996-02-08', '9966200052', 'mail2suhas@gmail.com'),
( 'E0005', 'Kabir Krishna', '84 Shantinagar Masab Tank', 'Faridabad', '1984-04-09', '9966255448', 'reach_kk@gmail.com'),
( 'E0006', 'Rushang Varma', '2/4 G.K. Mansions, waltair ', 'Noida', '1986-06-1', '9988850062', 'rushto_rushi@gmail.com'),
( 'E0007', 'Shalini Komaragiri', 'apt 4509 10th st, Kali Ghat rd, ', 'Noida', '1995-09-11', '9696932321', 'mailme_shalini@yahoo.com'),
( 'E0008', 'Amit Varma', '365 SadaSiva nagar', 'Faridabad', '1975-01-22', '4038285544', 'Amit_capri@gmail.com'),
( 'E0009', 'Rupesh Choudary', 'c-244 Madhura nagar', 'Gurgaon', '1980-08-12', '9394948000', 'rushto_rc1208@yahoo.com'),
( 'E0010', 'Aswini Rajagopalan', '843-c, Kamala Nagar', 'Delhi', '1995-10-31', '9394948554', 'AsRaja007@gmail.com');

Select * from emp;

alter table emp
add constraint uni_phno unique(phone);

alter table emp
add constraint ch_email check ((email like '%gmail%') or (email like '%yahoo%'));

alter table emp
add constraint ch_dob check (dob <= '1-Jan-2000');


------------ constraints to emp_sal table --------------
select * from emp_sal;

alter table emp_sal
add constraint fkid foreign key (eid) references emp(eid);

alter table emp_sal
add constraint def_dept default 'Temp' for dept;

alter table emp_sal
add constraint ch_dept check ( dept in ('HR', 'MIS', 'OPS', 'IT', 'ADMIN', 'Temp'));

select * from emp_sal;

update emp_sal set dept = 'ADMIN'
where eid = 'E0003';

update emp_sal set desi = 'Associate'
where desi = 'asst manager';

update emp_sal set desi = 'VP'
where desi = 'consultant';

alter table emp_sal
add constraint ch_desi check( desi in ( 'Associate', 'Manager', 'VP', 'Director'));

select * from EMP_SAL;





alter table emp_sal
add constraint ch_sal check (salary >= 20000);

insert into emp_sal
values ('E0002', 'IT', 'Manager', '2020-2-6', 30000);


----------------Assignment 4-----------------------
select * from emp;
select * from emp_sal;

-- from emp table display City wise count of employees arranged in descending order
select city, count(*) from emp
group by city
order by count(*) desc;

--from emp table display details of the employees who does not have an account on yahoo
select * from emp
where email not like '%yahoo%';

---from emp_sal table, display designation wise total cost and number of members 
---arranged in descending order of the total cost

select desi, count(*) as 'num of members', sum(salary) as 'total cost'
from emp_sal
group by desi
order by sum(salary) desc;


---------------------Assignment 5------------------
--from emp table display
--1) EID NAME CITY DOJ DEPT DESI SALARY of the delhi employees

select e.eid, e.name, e.city, es.doj, es.dept, es.salary
from emp e
left join emp_sal es
on e.eid = es.eid
where city = 'DELHI';


--2) details of the employees whose salary details are not available
select e.eid, e.name, e.city, es.doj, es.dept, es.salary
from emp e
left join emp_sal es
on e.eid = es.eid

except 

select e.eid, e.name, e.city, es.doj, es.dept, es.salary
from emp e
inner join emp_sal es
on e.eid = es.eid;

--------------------ASSIGNMENT 6 FROM SESSION 4-----------------------------------
-- CREATE A VIEW EMP_SAL_DETAILS TO GET EID NAME DOJ DEPT DESI SALARYAS BASIC. ALSO CALCULATE HRA (15% OF BASIC), PF (9% OF BASIC),
--NET(BASIC+HRA+PF), GROSS(NET-PF).
CREATE VIEW EMP_SAL_DETAILS
AS
SELECT EMP.EID,NAME,DOJ,DEPT,DESI ,
        SALARY AS 'BASIC',
		SALARY*1.5 AS 'HRA',
		SALARY *0.9 AS 'PF',
		SALARY+SALARY*1.5+SALARY *0.9 AS 'NET'
		,SALARY+SALARY*1.5+SALARY *0.9-SALARY *0.9 AS 'GROSS' FROM EMP INNER JOIN EMP_SAL 
		ON EMP.EID=EMP_SAL.EID;
SELECT * FROM EMP_SAL_DETAILS;

-- 2) CREATE A VIEW TO DISPLAY EID,NAME, DOJ, DESI, DEPT OF ALL THEMANAGERS JOINED IN 2019.
CREATE VIEW EMP_MAN_2019
AS
SELECT EMP.EID,NAME,DOJ,DESI,DEPT
       FROM EMP INNER JOIN EMP_SAL 
	   ON EMP.EID=EMP_SAL.EID
	   WHERE DESI='MANAGER' AND DOJ>'2019';
SELECT * FROM EMP_MAN_2019;

select * from emp_sal;
create view sal_great
as
select dept,sum(salary) as 'total salary' from emp_sal  
group by dept
having sum(salary)>50000 ;
--order by [total salary] desc;

select * from sal_great order by [total salary] desc;





--3) CREATE A VIEW TO HOW MANY TEAM MEMBERS ARE THERE IN EACH DEPARTMENTS IN EACH CITY, ALONG WITH THERE TOTAL & AVERAGE SALARY.
CREATE VIEW TEAM_DETAILS
AS
SELECT COUNT(DEPT) AS 'Team Size',DEPT,SUM(SALARY) AS 'TOTAL SALARY',AVG(SALARY) AS 'AVG SAL',CITY
       FROM EMP INNER JOIN EMP_SAL
	   ON EMP.EID=EMP_SAL.EID
	   GROUP BY DEPT,CITY;
SELECT * FROM TEAM_DETAILS;

--4) IN THE INVENTORY STRUCTURE GENERATE A VIEW BILL. IT SHOULD DISPLAYOID,ODATE,CNAME,ADDRESS,PHONE,PDESC, PRICE, OQTY, AMOUNT

------------------Assignment 6'------------
-- A-1: DEPARTMENT WISE TEAM SIZE AND AVERAGE SALARY OF ALL EMPLOYEES.
select dept,count(dept) as "Team Size",avg(salary) as " avg sal" from EMP_SAL
group by dept;
--order by Salary;


-- A-2 : COUNT OF MANAGERS IN THE COMPANY
select * from emp_sal;
select * from emp;
select count(desi) from emp_sal 
where desi='Manager';

--  MAXIMUM & MINIMUM SALARY OF AN ASSOCIATE
select max(salary),min(salary) from EMP_SAL;

--3 DEPARTMENT WISE TEAM SIZE AND AVERAGE SALARY
select  dept,count(dept) as 'Team Size',  avg(salary) as "avg sal" from EMP_SAL
group by dept;

--4 DEPARTMENT WISE TEAM SIZE AND AVERAGE SALARY OF DELHI EMPLOYEES.
select  count(dept) as 'Team Size',  avg(salary) as "avg sal" ,City
from EMP 
inner join emp_SAL 
on EMP.eid=EMP_SAL.eid
where city='delhi'
group by dept,city;


select dept,salary,city 
from emp 
inner join emp_sal
on emp.eid=emp_sal.eid
where city='Delhi';


-- : GENERATE OFFICIAL EMAIL OF THE EMPLOYEE TAKING 1ST CHARATCET OF FIRST 
-- NAME , 1ST CHARATCER OF LAST NAME , LAST 3 DIGITS OF EID, FOLLED BY �RCG.COM�. 
-- EMAIL SHOULD BE IN A UPPER CASE
select * from emp;
SELECT EID, NAME,
CHARINDEX(' ', NAME) as 'S',
LEN(NAME) AS 'L',
upper(
concat(
LEFT(NAME, 1),
Left(RIGHT(NAME,LEN(NAME)- CHARINDEX(' ', NAME)),1),
right(eid,3),'@RCG.COM')) AS 'CORP MAIL' from emp;


-- A-6: NAME,CITY , PHNO & EMAIL OF THE EMPLOYEES WHOSE AGE >=40
select name,city,phone,email,DOB,DATEDIFF(YY,DOB,GETDATE())  as 'age grt 40'
from emp where DATEDIFF(YY,DOB,GETDATE())>=40 ;


-- A-7 EID, NAME DOJ OF EMPLOYEES WHO HAVE COMPLETED 5 YEARS IN THE COMPANY
select emp.EID,name,doj,DATEDIFF(YY,DOJ,GETDATE()) as 'greater than 2 yrs of exp' 
from emp 
inner join EMP_SAL
on emp.eid=EMP_SAL.eid
where DATEDIFF(YY,DOJ,GETDATE())>2;


-- A-8: DETAILS OF THE MANAGERS HAVING BIRTHDAY IN THE CURRENT MONTH

select  emp.EID,name,ADDR,CITY,DOB,desi
from emp
inner join EMP_SAL
on emp.eid= EMP_SAL.eid
where month(dob)=DATEPART(M,GETDATE()) and  -- AS'MTH';
desi='manager';


select  emp.EID,name,ADDR,CITY,DOB,desi
from emp
inner join EMP_SAL
on emp.eid= EMP_SAL.eid
where desi='manager';

--A-9 : EID, DEPT , DESI , SALARY OF THE EMPLOYEE WHO IS GETTING THE MAXIMUM SALARY

select * from emp_sal;
select eid,dept,salary from EMP_SAL where salary=(select max(salary) from EMP_SAL);

SELECT EID,dept ,salary,max(salary)
FROM Emp_sal
WHERE salary = (
                SELECT max(salary)
                FROM EMP_SAL
               )
GROUP BY eid;
-- A-10 : EID, NAME OF EMPLOYEE WHO HAS LONGEST NAMe
select name,len(name) from emp order by len(name) desc;

select top 1 name,eid, LEN(name) as name_Length from emp order by name_Length desc;


----Assignment 7-----------------------
-- 1 CREATE A FUNCTION CALC TO PERFORM THE SPECIFIED OPERATION ON THE GIVEN TWO NUMBERS
create function cal(@x as int,@y as int,@o as char (1))
returns int
as
begin 
	  DECLARE @R AS INT;

	  IF @O = '+'
		SET @R = @X + @Y;
	  ELSE  IF @O='-'
	    SET @R=@X-@Y;
	  ELSE IF  @O='*'
	    SET @R=@X*@Y;
	  ELSE IF  @O='/'
	    SET @R=@X/@Y;
	  ELSE IF  @O='%'
	   SET @R=@X%@Y;
	   ELSE
	   SET @R = 0;
	
	RETURN @R;
END;

SELECT DBO.CAL(25,4,'$');
SELECT DBO.CAL(25,4,'*');

--A-2: FUNCTION TO GENERATE THE EMAIL ID BY ACCEPTING NAME & EID. EMAIL SHOULD CONTAIN 1ST CHARACTER OF 1ST NAME ,
-- 1ST CHARACTER OF LAST NAME, LAST 3 DIGITS OF EMP ID FOLLOWED BY @RCG.COM;
CREATE FUNCTION EMAIL()
RETURNS TABLE 
AS 
          RETURN(select eid,name,
                charindex(' ',name) as 's',
                len(name) as 'L',
                UPPER(
                CONCAT(LEFT(NAME,1),
                LEFT(RIGHT(NAME,LEN(NAME)-CHARINDEX(' ',NAME)),1),
				RIGHT(EID,3),'@RCG.COM')) AS 'CORP EMAIL' FROM EMP);
select * from dbo.email()


--A-3: FUNCTION TO RETURN EID, NAME, DESI, DEPT ,SALARY OF THE EMPLOYEES OF A SPECIFIED DEPARTMENT 
select dept from emp_sal;-- IT,ADMIN,MIS,OPS

create function dept(@d as varchar(10))
returns table
as
     RETURN (select emp.EID, NAME, DESI, DEPT ,SALARY FROM EMP
		INNER JOIN EMP_SAL on  EMP.EID=EMP_SAL.EID where dept=@d);
select * FROM  dbo.dept('IT')
select * FROM  dbo.dept('OPS')

--4: FUNCTION TO DISPLAY THE NAME , DEPT . DESI , CITY OF THE EMPLOYEES WHO HAVE THE BIRTHDAY IN THE CURRENT MONTH
	CREATE FUNCTION BIRTHDAY1()
	returns table 
	as 
	 return(select NAME, DEPT ,DESI , CITY from emp
	 inner join emp_sal on emp.eid=emp_sal.EID 
	 where month(dob)=DATEPART(M,GETDATE())
	 );
	 select * from dbo.BIRTHDAY1()

--A-5: FUNCTION TO DISPLAY THE NAME, DEPT & DOJ OF EMPLOYEES WHO HAVE COMPLETED 5 YEARS IN THE COMPANY
select * from emp_sal;
create function exp()
returns table
as
  return(select name,dept,doj from emp 
           inner join emp_sal
		   on emp.eid=emp_sal.eid
		   where DATEDIFF(YY,DOJ,GETDATE())>5);
SELECT * FROM DBO.EXP();
--------------ASSIGNMENT 7------------------
-- A-1 : EID, NAME, CITY OF GURGAON EMPLOYEES
select eid,name,city from emp where city='GURGAON';


---A-2 : EID, NAME , DOJ ,DEPT, DESI & SALARY OF ALL MANAGERS
select emp.EID,name,DOJ,dept,desi,salary from emp
inner join emp_sal on emp.eid=emp_sal.eid
where desi='manager';

-- A-3: REDUCE THE SALARY OF ALL DELHI EMPLOYEES BY 10%
update emp_sal set SALARY=salary-SALARY*0.1 where  eid in (SELECT EID FROM EMP WHERE CITY = 'delhi');

--A-4 : DISPLAY THE EID, NAME , CITY, DOJ ,DEPT, DESI & SALARY OF THE TEAM MEMBERS OF DAVID & RAMESH GUPTA.

select emp_sal.eid,name,city,doj,dept,salary 
from emp
inner join emp_sal 
on emp.eid=emp_sal.eid
where dept in  (select dept from emp_sal  where  eid in
               (select eid from emp where name like 'ramesh gupta' or name like 'david'));
                                      



--A-5: CREATE A TRAINING TABLE CONTAINING EID, NAME, DEPT. INSERT THE DETAILS OF OPS TEAM MEMBERS IN THE TRAINING TABLE
drop table training;
create table training(eid char(5),name varchar(20),dept varchar(15),desi varchar(15));

select * from emp_sal;
alter table training alter column desi varchar(30);
delete from training;

insert into training(eid,name,dept,desi)
select emp.eid,name,dept,desi from emp inner join emp_sal on emp.eid=emp_sal.eid where dept='ops';
select * from training;


--A-6: DETAILS OF DIRECTORS SHOULD BE DELETED FROM THE TRAINING TABLE
delete from training where eid in ( select eid from emp_sal where desi='director')
select * from training;
--A-7: DISPLAY THE SALARY DETAILS OFF ALL EMPLOYES IF ANY OF THE TEAM MEMBER HAS SALARY MORE THAN 200000
select eid,salary from emp_sal  where exists(select eid,salary from emp_sal where salary>200000);


-- A-1 : CREATE A FUNCTION FOR AUTOGENERATION OF 5 CHARACTERS ALPHA NUMERIC ID. IT
-- SHOULD ACCEPT 2 PARAMETERS A CHARACTER AND THE NUMBER AND RETURN THE ID BY
-- CONCANATING THE CHARACTER , REQUIRED ZEROS AND THE SPECIFIED NUMBER
CREATE FUNCTION CID(@C AS CHAR(1),@I AS INT)
RETURNS CHAR(5)
AS 
BEGIN
    DECLARE @ID AS CHAR(5);
	IF @I<10
	    SET @ID=CONCAT(@C,'000',@I);
	ELSE IF @I<100
	    SET @ID=CONCAT(@C,'00',@I);
	ELSE IF @I<1000
	    SET @ID=CONCAT(@C,'0',@I);
	ELSE IF @I<10000
	    SET @ID=CONCAT(@C,@I);
	ELSE
	    SET @ID='NA';
		RETURN @ID;
END;
SELECT DBO.CID('C','1235');

