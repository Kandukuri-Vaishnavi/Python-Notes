create database inventory;
use inventory;
create table supplier(sid CHAR(5),sname VARCHAR(20),SADD varchar(30),scity varchar(25),sphone char(15),email char(15));
create table Product(pid CHAR(5),pdesc varchar(40),price INT,category varchar(10));
create table stock(sqty int,rol int,moq int);
create table cust(cid char(5),cname varchar(20),address varchar(20),city varchar(20) ,phone char(15) ,email char(15),dob date);
create table orders(oid char(5),odate date,oqty int);
Alter table supplier modify column sname VARCHAR(20) not null;
Alter table supplier modify column SADD varchar(30) not null;
alter table supplier modify column scity varchar(25) DEFAULT 'DELHI';
Alter table supplier modify column sphone char(15) unique;
Alter table supplier modify column email varchar(25);
Alter table cust modify column email varchar(25);
Alter table cust modify column address varchar(55);
Alter table product modify column pdesc varchar(40) not null;
Alter table product modify column price INT check(price>0);
Alter table product modify column category varchar(10) check(category in ("IT","HA","HC"));
Alter table STOCK   modify column sqty int check(sqty>=0);
Alter table STOCK   modify column rol int check (rol>0);
Alter table STOCK   modify column moq int check(moq>=5);
alter table cust    
modify column  cid char(5) not null,
modify column cname varchar(20) not null,
modify column address varchar(20) not null,
modify column city varchar(20) not null ,
modify column phone char(15) not null ,
modify column email char(15) not null,
modify column dob date check(dob<2000-01-01) ;
Alter table supplier modify column sid CHAR(5) Primary key;
Alter table product modify column PID char(5)  Primary key;
Alter table cust modify column  CID char(5) Primary Key;
Alter table product add column sid CHAR(5)  references supplier(sid) ;
Alter table orders add column pid CHAR(5)  references product(pid) ;
Alter table orders add column cid CHAR(5)  references cust(cid) ;
Alter table stock add column pid CHAR(5)  references product(pid) ;
select * from supplier;
insert into supplier values
('S0001','Rohit Gupta','Sector 56','GURGAON',8899001123,'rgupta@gmail.com'),
('S0002','Kapil Sharma','Jay Maa Apartments Flat 32	','PUNE',9999001099,'kSharma@gmail.com'),
('S0003','Archna Sharma','5C Karanpur','PUNE',9899249700,'ASharma@gmail.com'),
('S0004','Ranjeeta Goyal','Flat No 6A	Rajpur Road','DEHRADUN',9999002700,'rgoyal@gmail.com'),
('S0005','AMIT KAPOOR','B2/45 DDA FLATS','DELHI',989970701,'RK2@GMAIL.COM'),
('S0006','KONIKA KAPOOR	','C2-43 SUPERTECH','PUNE',8888909970,'KK@YAHOO.CO.IN');
select * from product;
insert into product values
("P0001","Foam Dinner Plate",600,"HA","s0002"),
("P0002","Key board",2000,"IT","s0005"),
("P0003","mouse",1800,"IT","s0003"),
("P0004","cpu",28000,"IT","s0003"),
("P0005","monitor",18000,"IT","s0006"),
("P0006","Mixer",6000,"HA","s0004"),
("P0007","juicer",3500,"HA","s0001"),
("P0008","microwave",17000,"HA","s0002"),
("P0009","dish washer",26000,"HA","s0005"),
("P0010","stove",30000,"HA","s0006"),
("P0011","termometer",290,"Hc","s0002"),
("P0012","face masks",169,"Hc","s0003"),
("P0013","bp machine",3000,"Hc","s0004"),
("P0014","laptop",70000,"IT","s0005"),
("P0015","pain relief spray",340,"HC","s0003"),
("P0016","Fridge",34000,"HA","s0006"),
("P0017","nebulizer",10000,"Hc","s0001");
select * from stock;
insert into stock values
(90,5,8,"P0001"),
(89,4,8,"P0004"),
(156,9,6,"P0009"),
(80,11,20,"P0005"),
(132,15,7,"P0011"),
(184,16,12,"P0015"),
(274,12,11,"P0012"),
(195,08,05,"P0009"),
(100,8,6,"P0008"),
(120,9,8,"P0002");
select * from cust;
insert into cust values
("C0001","MONIKA KAPOOR","A401 PRAGYA appts","DELHI",9900000212,"MK32@YAHOO.CO.IN",'1990-1-01'),
("C0002","ANJAN SINGH","A212/5 PALAM VIHAR","GURGAON",9912340090,"AS32@YAHOO.COM",'1989-07-10'),
("C0003","MIKE","C2-141	VASANT VIHAR","PUNE",8800000078,"MIKE@YAHOO.COM",'1989-10-21'),
("C0004","RAGHUVEER SINGH","B72/3 TEACHERS COLONY ","CHANDIGARH",9899787870,"RS61@OUTLOOK.COM",'1997-01-10'),
("C0005","SANDEEP SHARMA","SECTOR 32 GEETA COLONY",	"CHANDIGARH",9899898970,"SS065@GMAIL.COM",'1989-12-12'),
("C0006","ABHISHEK BHIST","HNO 420, SIDDHARTH COLONY","GOREGAON",9899898909,"AB66@OUTLOOK.COM",'1998-08-01');
select * from orders;
insert into orders values
("O0001","2022-07-31",5,"P0007","C0003"),
("O0002","2020-09-14",9,"P0001","C0005"),
("o0003","2022-06-19",3,"p002","c0001"),
("o0004","2019-05-29",12,"p0010","c0006"),
("o0005","2021-09-29",6,"P0005","c0002");
-- pid,pdesc,category,sname,scity
select pid,pdesc,category,sname,scity
from product p
inner join supplier s
on p.sid=s.sid;
-- oid,odate,cname,caddress,cphone,pdesc,price,oqty,amt as price * oqty
select * from orders;
select oid,odate,cname,c.address,c.phone,pdesc,p.price,oqty,p.price*oqty as amt
from orders o
inner join cust c
on o.cid=c.cid
join product p
on o.pid=p.pid;
















