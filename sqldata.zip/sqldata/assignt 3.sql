use demo;
create table emp1 (
empid char(10) primary key,
name varchar(25) not null,
addr varchar(25) check (addr not like "%uttam nagar%"),
city varchar(25) check(city in ('del','ggn','fbd','noida')),
phone int(12) unique,
email varchar(20)check (email like 'yahoo' or email  like'gmail'),
dob date check(dob<='1990-1-1'));
create table em0_sal1(
empid char(10) ,
dept varchar(20) check(dept in('HR','MIS','OPS','IT ADMIN','TEMP')),
desi varchar(20) check(desi in ('asso','mgr''vp','dir'))
,sal int check(sal>=20000),
doj date,
foreign key (empid) references emp1(empid));
alter table emp_sal1 modify column desi varchar(20) check(desi in ('asso','mgr','vp','dir'));
insert into emp_sal1 values ('e0001','hr','asso',250000,'2020-06-09'),
                             ('e0002','mis','asso',270000,'2021-03-09'),
                             ('e0003','ops','vp',300000,'2022-04-09'),
                             ('e0004','IT ADMIN','dir',300000,'2022-04-09'),
                             ('e0005','temp','mgr',200000,'2022-03-06');
                             
alter table em0_sal1 rename emp_sal1;
set @@session.sql_safe_updates=1;
alter table emp1 drop dob;
alter table emp1 add column  dob date check(dob<='1990-01-01');
select * from emp1;
show columns from emp1;
INSERT INTO  EMP1
 values -- ('E0001','neha','banglore','del',82067489,'neha@gmail.com','1989-02-02'),
 -- ('E0002','haritha','pune','ggn',920678989,'haritha@gmail.com','1979-01-02');
  -- ('E0003','ramya','hyd','fbd',789678989,'ramya@yahoo.com','1989-05-09');
  ('E0004','sneha','banglore','noida',710678989,'sneha@gmail.com','1978-07-05'),
  ('E0005','teju','secbad','ggn',800678989,'teju@gmail.com','1987-011-06');
  delete  from emp1 where empid='E0002';--  and empid='E0002';