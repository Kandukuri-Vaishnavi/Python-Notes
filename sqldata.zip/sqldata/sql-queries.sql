use demo;
select * from emp;
create table employee(eid char(5),name varchar(20),address varchar(20),DOB Date,phone char(15),email_id char (15));
insert into employee Values('E0001','Alekhya','Banglore','1997-03-16',9923974910,'Alekhya01@gmail.com'),
							('E0002','Bhanu','Hyderabad','1999-01-11',8037916720,'AryaBhanu@gmail.com'),
                            ('E0003','Chendu','Pune','1989-03-21',7039702792,'chendu12@gmail.com'),
                            ('E0004','Divya','Chennai','2002-06-3',6039510392,'TummalaDivya6@yahoo.com'),
                            ('E0005','Eugine ross','USA','1975-08-04',82503961885,'eug04@gmail.com'),
                            ('E0006','Fathima','Uk','1982-09-23',6038941027,'Fathimak@yahoo.com'),
                            ('E0007','Greeshma','Kochi','1999-03-04',8230917457,'Greesh45@gmail.com'),
                            ('E0008','Harish','Kerala','2003-03-16',9234086591,'khari@gmail.com'),
                            ('E0009','Imran','Goa','1999-02-08',9245016920,'Iamimrankhan@yahoo.com'),
                            ('E0010','John','NY','1786-05-23',7029409289,'Johnkaran@gmail.com');
select * from employee;
Alter table employee modify email_id  varchar(30);
create table employee_sal(EID char(5),Dept varchar(25),Desi varchar(20),Doj date,salary int);
insert into employee_sal Values('E0001','IT','Associate','2020-3-15',200000),
							    ('E0002','Production','SR Associate','2005-10-07',500000),
                                ('E0003','QEA','Programmer','2020-11-28',40000),
                                ('E0004','HR','Analyst','2019-07-13',370000),
                                ('E0005','IT','intern','2022-05-31',18000),
                                ('E0006','HR','Associate','2017-07-18',300000),
                                ('E0007','IT','Manager','2004-06-19',500000);
select * from employee_sal;
select name from employee where name like '%sharma%';
set @@session.sql_safe_updates=1;
update employee_sal set salary=salary+salary*0.1 where Desi='manager';
create table Empone(
EMPID char(5) primary key,
Name varchar(25) not null,
 addr varchar(30) check (addr not like "%Uttamnagar%"),
 city varchar(20) check(city in ('del','ggn','fbd','noida')),
 phone char(20) unique,
 email varchar(25) check(email like "%yahoo%" or email like "%gmail%"),
dob date check(dob<='2000-1-1'));
INSERT INTO  EMPone
 values ('E0001','neha','banglore','del',82067489,'neha@gmail.com','1989-02-02'),
        ('E0002','haritha','pune','ggn',920678989,'haritha@gmail.com','1979-01-02'),
	    ('E0003','ramya','hyd','fbd',789678989,'ramya@yahoo.com','1989-05-09'),
        ('E0004','sneha','banglore','noida',710678989,'sneha@gmail.com','1978-07-05'),
	    ('E0005','teju','secbad','ggn',800678989,'teju@gmail.com','1987-011-06');
INSERT INTO  EMPone
values('E0006','Fathima','lane 22 smr colony','noida',6038941027,'Fathimak@yahoo.com','1982-09-23'),
		('E0007','Greeshma','princeton street','fbd',8230917457,'Greesh45@gmail.com','1999-03-04'),
		('E0008','Harish','sarojini road','del',9234086591,'khari@gmail.com','1997-03-16'),
		('E0009','Imran','ggn colony ','ggn',9245016920,'Iamimrankhan@yahoo.com','1999-02-08'),
		('E0010','John','12 street road 10 vasipur','noida',7029409289,'Johnkaran@gmail.com','1986-05-23');
create table empone_sal
(empid char(5) REFERENCES empone(empid),
 dept varchar(20) check(dept in ('hr','mis','ops','it admin','temp')) default 'temp',
 desi varchar(20) check(desi in('asso','mgr','vp','dir')),
 basicsal int check(basicsal>=20000),
 doj date);
 insert into empone_sal values ('e0001','hr','asso',250000,'2020-06-09'),
                             ('e0002','mis','asso',270000,'2021-03-09'),
                             ('e0003','ops','vp',300000,'2022-04-09'),
                             ('e0004','IT ADMIN','dir',300000,'2022-04-09'),
                             ('e0005','temp','mgr',200000,'2022-03-06');
 insert into empone_sal values('E0006','HR','Asso',400000,'2017-07-18'),
							  ('E0007','IT admin','Mgr',500000,'2004-06-19');
select * from empone_sal;
-- CITY WISE COUNT OF EMPLOYEES ARRANGED IN DESCENDING ORDER
select  city, count(empid)  from empone 
group by city
order by count(empid) desc;
-- DETAILS OF THE EMPLOYEES WHO DOES NOT HAVE AN ACCOUNT ON YAHOO
select * from empone where email not like "%yahoo%";
-- From the Emp_Sal table display:
-- DESIGNATION WISE TOTAL sal AND NUMBER OF MEMBERS ARRANGED IN
-- DESCENDING ORDER OF THE TOTAL sal
select desi,sum(basicsal) ,count(empid) from empone_sal
group by desi
order by sum(basicsal) desc;
-- IN THE EMP TABLE DISPLAY :
--  1 ) EID NAME CITY DOJ DEPT DESI SALARY OF THE DELHI EMPLOYEES
select empone.empid,name,city,doj,dept,desi,basicsal
from empone 
inner join empone_sal
on  EMPone.empid=empone_sal.empid
where city="del";
-- 2 ) DETAILS OF ALL THE EMPLOYEES WHOSE SALARY DETAILS ARE NOT AVAILABLE.
select empone.empid,name ,addr,city,DOB,phone,email,Dept ,Desi, Doj ,basicsal
from empone
left join empone_sal
on empone.eid=empone_sal.eid 

EXCEPT

select empone.empid,name ,addr,city,DOB,phone,email,Dept ,Desi, Doj ,basicsal
from empone
right join empone_sal
on empone.eid=empone_sal.eid ;

select * from employee;
select * from employee_sal;
					
 

